# SelfBot-Ver-1.5
# 這是一個LINE的聊天輔助系統
# 為單人帳號的小程式
# 具有多種群組功能與個人輔助
# 執行方法(僅簡介Android的方法)
# 請安裝以下app:
# 1.Termux
# 2.Quick Edit
# 3.Hackers keyboard
# 於Termux中逐行貼上以下內容:
# pkg install python -y
# pkg install git -y
# pkg install nano -y
# pip install thrift==0.11.0
# pip install requests
# pip install rsa
# git clone https://github.com/KazumiLine/SelfBot-Ver-1.5
# cd SelfBot-Ver-1.5
# ls
# python run.py