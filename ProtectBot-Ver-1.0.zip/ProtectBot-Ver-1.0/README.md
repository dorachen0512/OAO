# ProtectBot-Ver-1.0
# 這是一個LINE的群組防翻系統
# 為五隻帳號的小程式
# 主要功能為踢人反踢
# 請至pro.py輸入你的Token
# 請將程式中LINE("")的雙掛號內資料換成你的token
# 若第一次使用token可以留空
# 執行方法(僅簡介Android的方法)
# 請安裝以下app:
# 1.Termux
# 2.Quick Edit
# 3.Hackers keyboard
# 於Termux中逐行貼上以下內容:
# pkg install python -y
# pkg install git -y
# pkg install nano -y
# pip install thrift==0.11.0
# pip install requests
# pip install rsa
# git clone https://github.com/KazumiLine/ProtectBot-Ver-1.0
# cd ProtectBot-Ver-1.0
# ls
# python pro.py